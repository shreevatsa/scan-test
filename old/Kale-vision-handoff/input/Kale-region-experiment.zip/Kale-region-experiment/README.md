# Kale scanned-book region experiment

The accompanying `Kale-region-comparison.pdf` contains the findings and annotated
side-by-side comparisons. This archive contains the reproducible implementation
and raw data. It is an exploratory comparison, not a validated automatic cropper
or a deployed web app.

## What was tested

- 24 selected pages out of 252 in `Kale-1913-pp21-272.pdf`.
- All page numbers are 1-based PDF positions, not printed page labels.
- Page images were rendered at 300 dpi. The existing OCR/text layer was ignored.
- A custom geometry baseline; k2pdfopt itself was not executed.
- PP-DocLayout-S: community ONNX export, 480x480 input, threshold 0.30.
- PP-DocLayoutV3: community ONNX export, 800x800 input, threshold 0.30, with the
  0.50 result retained as a sensitivity check.
- Hybrid: V3 plus connected-component boundary extension and residual-ink boxes.

Sample pages: 1, 2, 3, 9, 17, 25, 33, 49, 57, 65, 81, 97, 113, 114, 121, 137,
145, 161, 169, 177, 193, 209, 233, 252.

## Findings

The regular English and mixed-script notes are easier for both learned models
than the Sanskrit verse/commentary pages. V3 needs a less restrictive confidence
threshold to retain much of the verse. The simple geometry baseline preserves
most ink but merges or fragments blocks, and has major omissions on page 113.
The hybrid covers more measured ink but does not solve every grouping problem.

The final measured foreground coverage across all sampled pages is approximately
97.80% geometry, 94.41% small model, 98.65% V3 at 0.30, and 99.94% hybrid.

**Coverage is not segmentation accuracy.** An enclosing page rectangle would
have perfect coverage. There is no independently annotated ground-truth set or
formal manual-correction benchmark. Boxes and order remain proposals.

The measurement mask excludes the top 2.5%, bottom 6%, left 2.5%, and right 2%
of each image, very small components, narrow tall scan borders, and some long
thin rules. The bottom exclusion is specific to this book's Google watermark.
Short ornaments, stray marks and other non-text material can remain. Do not
reuse these exclusions on arbitrary books without checking content near edges.

The geometry implementation is intentionally small. It lacks k2pdfopt's complete
column search and many text-row refinements. It was adjusted on pilot pages
before the final run, so this is not a blind benchmark.

## Files

- `results/regions.json`: all boxes in 300-dpi rendered-image coordinates,
  labels, scores, proposed order, low-confidence V3 candidates, timings, and
  per-page coverage diagnostics. V3 candidates down to score 0.20 are retained.
- `results/review-notes.json`: qualitative observations for the 24 samples.
- `models.json`: exact model revisions, download URLs, byte sizes and SHA-256s.
- `compare_regions.py`: geometry, inference, refinement, diagnostics and overlays.
- `refine_results.py`: threshold changes using saved candidates, no re-inference.
- `make_report.py`: report generation, reusing original-resolution PDF scans.
- `offline_run.py`: Linux seccomp wrapper that denies network socket creation
  and connection/send syscalls before loading inference libraries.
- `download_models.py`: public-model download and hash verification only.
- `Kale-region-preview.png`: one of the final comparison plates.

No model weights or source PDF are bundled. The original PDF SHA-256 is in the
results JSON. The models occupy about 147 MB combined; source code and results
are much smaller.

## Reproduce

Use Python 3.12 on Linux. The PDF report can be inspected on any PDF viewer.

```bash
python -m pip install -r requirements.txt
python download_models.py
python offline_run.py compare_regions.py /path/to/Kale-1913-pp21-272.pdf
python offline_run.py make_report.py --source /path/to/Kale-1913-pp21-272.pdf
```

To change the V3 threshold, edit the explicit filter in `refine_results.py` and
recompute the report. Its raw candidates stop at 0.20. To select different test
pages, use `compare_regions.py --pages 9 17 97`; the report includes notes for the
original sample only, so supply notes if adding other pages.

Inference uses CPUExecutionProvider with two intra-op threads. Reported model
times include resizing/normalization and inference, after model load, but exclude
PDF rendering, mask construction, diagnostics and visualization. They are not
browser measurements. Geometry's recorded timer excludes its mask pass.

## Implementation notes

Small-model preprocessing follows the upstream inference YAML: cubic resize,
rescale by 1/255, ImageNet mean/std. Class-agnostic IoU suppression at 0.55 removes
some duplicate class predictions. V3 box decoding and pairwise order voting are
NumPy translations of the official Hugging Face postprocessor. V3 polygon masks
are not evaluated here. The hybrid re-sorts boxes spatially after refinement;
the small model and geometry also use spatial order on these single-column
pages. V3's raw learned order is retained in the JSON.

Model inference telemetry is disabled both through ORT_DISABLE_TELEMETRY=1 and
onnxruntime.disable_telemetry_events(). The final reported inference run also
used the socket-denying seccomp wrapper. That wrapper needs libseccomp on Linux;
it deliberately fails rather than silently running with network access.

Model exports inherit Apache-2.0 licenses. Attribution and exact upstream links
are in `models.json`; reference postprocessing source is in `reference/`.
