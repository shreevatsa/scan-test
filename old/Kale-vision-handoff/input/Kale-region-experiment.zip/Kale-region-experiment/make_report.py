#!/usr/bin/env python3
"""Create a comparison PDF with original-resolution scans and vector boxes."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import statistics

import cv2
import fitz
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

from compare_regions import ROOT, make_mask, rasterize_boxes

OUT=ROOT/'output'
OUT.mkdir(exist_ok=True)
DATA=json.loads((ROOT/'results/regions.json').read_text())
RECORDS=DATA['records']
NAMES={'geometry':'Geometry baseline','small':'PP-DocLayout-S / 0.30',
       'large':'PP-DocLayoutV3 / 0.30','hybrid':'V3 + pixel refinement'}
NOTES={
1:'Contents page. A whole section box and one box per entry are both plausible outputs; box count alone is not a quality score. The small model also proposes a large enclosing region.',
2:'Sanskrit title and opening verse. Notice inconsistent splits within centered text and nested model boxes. The detector labels have no dedicated verse category.',
3:'Sanskrit prose, centered verse and small apparatus. The geometric baseline preserves the page but does not consistently separate the apparatus or keep the verse together.',
9:'Sanskrit commentary and verse. At threshold 0.50, V3 leaves nearly half the measured ink uncovered. Lowering to 0.30 recovers most of it; pixel recovery handles much of the remainder.',
17:'Two verses interleaved with commentary. Several methods split a verse into lines, or attach its last line to the following prose. Extra coverage does not solve that grouping problem.',
25:'Several verse/prose transitions. The small detector omits substantial verse text. The geometry baseline tends to carry the last verse line into a prose region.',
33:'Useful counterexample to coverage as accuracy: the small model covers almost all ink using an enclosing body box, while losing the internal verse/commentary structure.',
49:'Page with a short body and closing ornament. Missing ornaments contribute to the ink metric even when text is present. Avoid treating every recovered mark as a text block.',
57:'The small model misses verse material. V3 at 0.30 covers almost all measured ink, but tends toward one region per verse line.',
65:'Sanskrit with an embedded English gloss. Verse fragments receive weaker model scores than prose. Pixel recovery protects content, with further grouping still needed.',
81:'Pencil/scan marks and centered verse. The remaining uncovered ink includes material the detectors do not interpret as text. The mask is a diagnostic, not a transcription oracle.',
97:'A strong confidence-threshold example. V3 coverage changes from about 33% at 0.50 to about 96% at 0.30. This is calibration sensitivity, not proof that the page has no detectable structure.',
113:'A real geometry failure: line-band grouping loses substantial text on this crowded page. Both learned detectors preserve considerably more. A deterministic algorithm can still omit content.',
114:'English translation begins. All approaches find useful text blocks; some numbered entries are merged by the geometric baseline. Heading ornaments remain a separate question.',
121:'Regular English paragraphs. Learned layout detection works well here. The geometric baseline mainly misses the running page number rather than body text.',
137:'Short English page with a large blank area. Closing ornaments and speckles explain part of the uncovered-ink score. Main paragraphs are found by all methods.',
145:'English numbered entries. Geometry merges adjacent entries that the models generally separate, despite essentially complete ink coverage.',
161:'English translation. The geometry baseline is too coarse for individual numbered entries; the learned layouts give more useful paragraph divisions.',
169:'Dense mixed-language notes. Main entries are identified by all methods. Pixel recovery can expand a tiny running header into an unnecessarily broad box if nearby noise is present.',
177:'Dense English notes with Sanskrit quotations. Major paragraph divisions are consistent. Small in-line script changes do not require separate regions.',
193:'Mixed-script commentary. All approaches provide usable coarse blocks. Check label semantics and box tightness before deciding that the regions are interchangeable.',
209:'Dense mixed-script notes. Content coverage is high for all approaches, while large commentary blocks remain large. Reading order is simple on this single-column page.',
233:'Another geometry failure: some complete text lines fall outside its blocks. Both learned detectors cover those lines. Pixel verification is useful for either family of algorithm.',
252:'Short final page. Model footer detections include the digitization watermark; the hybrid excludes that known watermark band. Isolated marks still need a keep/ignore decision.'}


def aggregate(rs,method,strict=False):
    vals=[r['large_default05_metrics'] if strict else r['metrics'][method] for r in rs]
    return 100*(1-sum(a['uncovered_ink_pixels'] for a in vals)/sum(a['ink_pixels'] for a in vals))


def summary():
    source_name=DATA['source']
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='BodyCustom',fontName='Helvetica',fontSize=10,leading=14,spaceAfter=9,textColor=colors.HexColor('#253744')))
    styles.add(ParagraphStyle(name='SmallCustom',fontName='Helvetica',fontSize=8,leading=11,spaceAfter=7,textColor=colors.HexColor('#405766')))
    styles.add(ParagraphStyle(name='LeadCustom',fontName='Helvetica-Bold',fontSize=15,leading=20,spaceAfter=14,textColor=colors.HexColor('#123d4c')))
    story=[]
    def para(text,kind='BodyCustom'):
        story.append(Paragraph(text,styles[kind]))
    para('SCANNED-BOOK REGION DETECTION','SmallCustom')
    para('What worked on the Kale scan','Title')
    para('A learned detector helps with grouping, but a foreground check is essential.','LeadCustom')
    para(f'Tested 24 selected pages from <b>{source_name}</b> (252 pages total). The sample covers contents, Sanskrit title/prose/verse, English translations, mixed-script commentary, and small footnotes. All detection used page images; the existing PDF text layer was ignored.')
    para('For this book, I would use a conservative geometric pass to protect content and a trained detector to suggest meaningful divisions. Neither raw approach is reliable enough to crop pages without review. The hybrid below is a prototype: it expands model boxes around intersected glyph components, then proposes boxes for substantial unassigned ink.')
    sanskrit=[r for r in RECORDS if 2<=r['pdf_page']<=113]
    english=[r for r in RECORDS if r['pdf_page']>=114]
    rows=[['Method','All 24','Sanskrit (12)','English / notes (11)']]
    for name in NAMES:
        rows.append([NAMES[name],f'{aggregate(RECORDS,name):.2f}%',f'{aggregate(sanskrit,name):.2f}%',f'{aggregate(english,name):.2f}%'])
    table=Table(rows,colWidths=[190,65,105,115],hAlign='LEFT')
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#154b5d')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTNAME',(0,1),(-1,-1),'Helvetica'),('FONTSIZE',(0,0),(-1,-1),8.5),('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#eef4f5'),colors.white]),('LINEBELOW',(0,-1),(-1,-1),.5,colors.HexColor('#ccd9df'))]))
    story.extend([table,Spacer(1,12)])
    para('<b>These percentages measure covered foreground pixels, not segmentation accuracy.</b> A single rectangle around the whole page can score 100% while being useless for region extraction. Borders, long rules, small speckles and the bottom 6% watermark band are excluded by a declared mask. Surviving ornaments and noise can still affect the numbers. The contents page appears only in the all-pages column.','SmallCustom')
    para('<b>The clearest contrast:</b> V3 covers about '+f'{aggregate(sanskrit,"large",True):.1f}% of measured Sanskrit ink at threshold 0.50, versus {aggregate(sanskrit,"large"):.1f}% at 0.30. The English/notes result is much steadier. On PDF page 97, the change is about 33% to 96%.')
    para('<b>Geometry has its own failures:</b> it merges several English numbered entries, fragments verses, and loses substantial text on PDF page 113. The small model sometimes encloses most of a page in one box, hiding poor grouping behind a high coverage score.')
    para('The following pages show all four methods side by side. Blue outlines are proposed regions; purple indicates model furniture labels; orange indicates ink recovered by the hybrid. Red pixels are foreground outside the union of proposed boxes. Numbers show proposed order, not verified final reading order.','SmallCustom')
    story.append(PageBreak())
    para('How to interpret and reproduce the test','Title')
    para('<b>Geometry baseline.</b> A small custom implementation uses foreground components, horizontal line bands, gaps, indentation and width changes. It was adjusted on pilot pages before the final sample run. It is inspired by whitespace analysis; k2pdfopt itself was not executed. This baseline does not implement the full column search and accumulated refinements in k2pdfopt.')
    para('<b>Small model.</b> PP-DocLayout-S, community ONNX export of the PaddlePaddle checkpoint. Input 480 x 480, official ImageNet normalization, threshold 0.30, followed by class-agnostic duplicate suppression at IoU 0.55. Source model is 4,917,852 bytes. Its learned boxes are ordered geometrically for this comparison.')
    para('<b>Larger model.</b> PP-DocLayoutV3, community ONNX export of the PaddlePaddle checkpoint. Input 800 x 800 with the supplied rescaling, threshold 0.30. The 0.50 result is retained for sensitivity analysis. Box decoding and pairwise reading-order votes follow the official Hugging Face implementation. This test uses axis-aligned boxes, not instance-segmentation polygons. Graph plus weights total 141,862,647 bytes.')
    para('<b>Hybrid.</b> Uses V3 at 0.30, extends rectangles to include intersected connected components where the required extension is small, and adds geometric proposals for substantial residual ink. Original scan pixels remain the output material. This improves coverage; it does not resolve every verse/paragraph boundary, nested box, annotation, or label error.')
    median_s=statistics.median(r['timings_seconds']['small'] for r in RECORDS)
    median_l=statistics.median(r['timings_seconds']['large'] for r in RECORDS)
    para(f'<b>Measured inference cost.</b> Median preprocessing plus inference on this machine: small model {median_s*1000:.0f} ms/page; V3 {median_l:.2f} s/page, CPU only, two inference threads, after loading weights. Geometry grouping itself took about {statistics.median(r["timings_seconds"]["geometry"] for r in RECORDS)*1000:.0f} ms, excluding its shared foreground-mask pass. Rendering, loading, metrics and preview generation are excluded. These are not browser or phone timings.')
    para('<b>Scope.</b> This is a one-book exploratory comparison, with automated diagnostics on 24 pages and visual review of their overlays. There is no independently annotated ground-truth set, formal region accuracy score, counted manual-edit benchmark, or proof of correct reading order. Most pages are single-column, so this does not validate complex multi-column reading order.')
    para('<b>Practical next step.</b> Build an editable region overlay with keep/ignore, split/merge and order controls. Always flag substantial unassigned ink. Use model confidence as a review cue, not permission to discard text. Evaluate a few more books before choosing a default model or threshold.')
    para('<b>Reproducibility.</b> The accompanying archive contains scripts, pinned model URLs and SHA-256 hashes, raw boxes including low-confidence candidates, per-page metrics, and review notes. Model weights and the source PDF are referenced rather than bundled. Inference ran with ORT telemetry disabled and network socket creation denied by a Linux seccomp wrapper.','SmallCustom')
    para('Model sources: PaddlePaddle/PP-DocLayout-S and PaddlePaddle/PP-DocLayoutV3_safetensors on Hugging Face. ONNX exports: stefanj0/PP-DocLayout-S-ONNX and Bei0001/PP-DocLayoutV3-ONNX. Exact revisions and full download URLs are recorded in models.json.','SmallCustom')
    def footer(canvas,doc):
        canvas.setStrokeColor(colors.HexColor('#d5e0e5'));canvas.line(48,39,A4[0]-48,39)
        canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#546b78'))
        canvas.drawString(48,26,'Kale scan | image-only region experiment')
        canvas.drawRightString(A4[0]-48,26,str(doc.page))
    doc=SimpleDocTemplate(str(OUT/'summary-temp.pdf'),pagesize=A4,leftMargin=48,rightMargin=42,topMargin=38,bottomMargin=49)
    doc.build(story,onFirstPage=footer,onLaterPages=footer)


def color(item):
    if item.get('origin')=='unassigned_ink':return (0.77,.42,.02)
    if item['label'] in ['header','number','footer','footer_image']:return (.48,.33,.68)
    return (.025,.48,.68)


def annotate(pdf_page,source,source_index,rect,items,rgb,mask):
    src=source[source_index]
    scale=min(rect.width/src.rect.width,rect.height/src.rect.height)
    placed=fitz.Rect(rect.x0+(rect.width-src.rect.width*scale)/2,rect.y0,
                     rect.x0+(rect.width+src.rect.width*scale)/2,rect.y0+src.rect.height*scale)
    pdf_page.show_pdf_page(placed,source,source_index,keep_proportion=True)
    h,w=rgb.shape[:2]
    missed=(mask>0)&(rasterize_boxes(items,mask.shape)==0)
    if missed.any():
        missed=cv2.dilate(missed.astype(np.uint8),np.ones((2,2),np.uint8))>0
        overlay=np.zeros((h,w,4),np.uint8);overlay[missed]=[228,35,65,220]
        buf=io.BytesIO();Image.fromarray(overlay).save(buf,format='PNG')
        pdf_page.insert_image(placed,stream=buf.getvalue(),overlay=True)
    sx=placed.width/w;sy=placed.height/h
    for index,item in enumerate(items):
        x1,y1,x2,y2=item['box']
        box=fitz.Rect(placed.x0+x1*sx,placed.y0+y1*sy,placed.x0+x2*sx,placed.y0+y2*sy)
        col=color(item)
        pdf_page.draw_rect(box,color=col,width=.65)
        label=str(index+1);fs=5.7;tw=fitz.get_text_length(label,fontname='hebo',fontsize=fs)+4
        y=max(placed.y0,box.y0-8)
        lab=fitz.Rect(max(placed.x0,box.x0),y,max(placed.x0,box.x0)+tw,y+8)
        pdf_page.draw_rect(lab,color=col,fill=col,width=0)
        pdf_page.insert_text((lab.x0+2,lab.y0+6.4),label,fontname='hebo',fontsize=fs,color=(1,1,1))
    return placed


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source',type=Path,default=ROOT.parent/'upload'/DATA['source'])
    args=parser.parse_args()
    if hashlib.sha256(args.source.read_bytes()).hexdigest()!=DATA['source_sha256']:
        raise ValueError('Source PDF does not match the recorded experiment')
    summary()
    source=fitz.open(args.source)
    result=fitz.open(OUT/'summary-temp.pdf')
    for rec in RECORDS:
        pn=rec['pdf_page'];sp=source[pn-1]
        pix=sp.get_pixmap(matrix=fitz.Matrix(300/72,300/72),alpha=False)
        rgb=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,3).copy()
        mask,*_=make_mask(rgb)
        page=result.new_page(width=1191,height=650)
        page.insert_text((28,31),f'PDF page {pn} / {DATA["source_pages"]}',fontsize=18,fontname='hebo',color=(.07,.22,.29))
        page.insert_text((28,50),'Region proposals on the original scan. Red = unassigned foreground; orange = pixel recovery.',fontsize=10,color=(.28,.37,.42))
        gap=16;cw=(1191-56-3*gap)/4
        for i,name in enumerate(NAMES):
            x=28+i*(cw+gap)
            page.insert_text((x,78),NAMES[name],fontsize=11,fontname='hebo',color=(.05,.29,.37))
            mm=rec['metrics'][name]
            page.insert_text((x,93),f"{len(rec['regions'][name])} regions | {mm['ink_coverage']*100:.2f}% measured ink covered",fontsize=8.2,color=(.27,.36,.41))
            annotate(page,source,pn-1,fitz.Rect(x,105,x+cw,525),rec['regions'][name],rgb,mask)
        page.draw_line((28,542),(1163,542),color=(.78,.84,.87),width=.6)
        remaining=page.insert_textbox(fitz.Rect(28,556,1163,607),NOTES[pn],fontsize=11,lineheight=1.35,color=(.15,.25,.31))
        if remaining<0:raise RuntimeError(f'Review note overflow on PDF page {pn}')
        page.insert_text((28,628),'Numbers are proposed order. Overlapping boxes and verse fragments can require manual merge/reorder. Coverage is not region accuracy.',fontsize=9,color=(.37,.44,.48))
        page.insert_text((1138,628),str(len(result)),fontsize=9,color=(.37,.44,.48))
    # One sensitivity plate makes the confidence effect directly reviewable.
    rec=next(a for a in RECORDS if a['pdf_page']==97)
    pn=97;pix=source[pn-1].get_pixmap(matrix=fitz.Matrix(300/72,300/72),alpha=False)
    rgb=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,3).copy();mask,*_=make_mask(rgb)
    page=result.new_page(width=1191,height=740)
    page.insert_text((28,32),'Confidence threshold changes what survives',fontsize=21,fontname='hebo',color=(.07,.22,.29))
    page.insert_text((28,53),'PDF page 97: same V3 inference, different score threshold. Filtering can remove readable text.',fontsize=11,color=(.28,.37,.42))
    for i,(title,items,mm) in enumerate([
        ('V3 at 0.50',rec['large_default05_regions'],rec['large_default05_metrics']),
        ('V3 at 0.30',rec['regions']['large'],rec['metrics']['large']),
        ('V3 at 0.30 + pixel recovery',rec['regions']['hybrid'],rec['metrics']['hybrid'])]):
        x=60+i*370
        page.insert_text((x,86),title,fontsize=13,fontname='hebo',color=(.05,.29,.37))
        page.insert_text((x,103),f"{mm['ink_coverage']*100:.2f}% measured ink covered",fontsize=10,color=(.28,.37,.42))
        annotate(page,source,pn-1,fitz.Rect(x,115,x+330,640),items,rgb,mask)
    page.insert_textbox(fitz.Rect(38,675,1153,724),'Confidence is not a keep/discard guarantee. The hybrid closes most coverage gaps but still needs region grouping and label review.',fontsize=12,color=(.15,.25,.31))
    result.set_metadata({'title':'Kale scanned-book region comparison','author':'','subject':'24-page exploratory comparison: geometry, PP-DocLayout-S, PP-DocLayoutV3 and pixel refinement'})
    result.save(OUT/'Kale-region-comparison.pdf',garbage=4,deflate=True)
    result.close()
    (OUT/'summary-temp.pdf').unlink()
    # A directly shareable overview of one informative failure case.
    pp=fitz.open(OUT/'Kale-region-comparison.pdf');idx=2+[r['pdf_page'] for r in RECORDS].index(17)
    pp[idx].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(OUT/'Kale-region-preview.png')
    print(json.dumps({'pages':len(pp),'pdf_bytes':(OUT/'Kale-region-comparison.pdf').stat().st_size,'preview_page':idx+1}))
    (ROOT/'results/review-notes.json').write_text(json.dumps(NOTES,indent=2))


if __name__=='__main__':main()
