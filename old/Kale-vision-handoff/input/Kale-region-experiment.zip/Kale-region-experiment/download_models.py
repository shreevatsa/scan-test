#!/usr/bin/env python3
"""Download public model files before processing any user document."""
import hashlib
import json
from pathlib import Path
import urllib.request

root=Path(__file__).resolve().parent
manifest=json.loads((root/'models.json').read_text())
for item in manifest['files']:
    path=root/item['path']
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']:
        print('Verified existing',item['path']);continue
    data=urllib.request.urlopen(item['url'],timeout=120).read()
    if hashlib.sha256(data).hexdigest()!=item['sha256']:
        raise ValueError('Hash mismatch for '+item['path'])
    path.write_bytes(data)
    print('Downloaded and verified',item['path'],len(data))
