#!/usr/bin/env python3
"""Image-only region detection experiment. No source PDF text extraction is used.

The geometric baseline is an original, simple whitespace/line-geometry baseline,
not an implementation or invocation of k2pdfopt. All page numbers are 1-based
positions in the supplied PDF, not printed page numbers.
"""
import argparse
import hashlib
import json
import os
import time
from pathlib import Path

os.environ['ORT_DISABLE_TELEMETRY'] = '1'

import cv2
import fitz
import numpy as np
import onnxruntime as ort
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import binary_closing, gaussian_filter1d
from scipy.special import expit

ort.disable_telemetry_events()

ROOT = Path(__file__).resolve().parent
PAGES = [1, 2, 3, 9, 17, 25, 33, 49, 57, 65, 81, 97,
         113, 114, 121, 137, 145, 161, 169, 177, 193, 209, 233, 252]
SMALL_LABELS = ['paragraph_title', 'image', 'text', 'number', 'abstract',
                'content', 'figure_title', 'formula', 'table', 'table_title',
                'reference', 'doc_title', 'footnote', 'header', 'algorithm',
                'footer', 'seal', 'chart_title', 'chart', 'formula_number',
                'header_image', 'footer_image', 'aside_text']


def session(path):
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 2
    opts.inter_op_num_threads = 1
    opts.log_severity_level = 3
    return ort.InferenceSession(str(path), sess_options=opts,
                               providers=['CPUExecutionProvider'])


def runs(active):
    d = np.diff(np.pad(np.asarray(active, np.int8), (1, 1)))
    return list(zip(np.where(d == 1)[0].tolist(), np.where(d == -1)[0].tolist()))


def make_mask(rgb):
    """Remove speckles, scan borders, long rules, and the watermark band.

    The bottom 6% exclusion is explicit and book-specific: it contains the
    Google digitization mark, not the actual body/footnotes on inspected pages.
    Metrics are restricted to this declared analysis window.
    """
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    h, w = gray.shape
    binary = (gray < 175).astype(np.uint8)
    binary[:int(.025*h)] = 0
    binary[int(.94*h):] = 0
    binary[:, :int(.025*w)] = 0
    binary[:, int(.98*w):] = 0
    n, labs, st, centroids = cv2.connectedComponentsWithStats(binary, 8)
    rule_rows=[(int(y),int(y+bh)) for x,y,bw,bh,area in st[1:]
               if bw>.4*w and bh<.008*h]
    keep = np.ones(n, np.uint8)
    keep[0] = 0
    keep[st[:, cv2.CC_STAT_AREA] < max(5, int(h*w/500000))] = 0
    keep[(st[:, 3] > .12*h) & (st[:, 2] < .012*w)] = 0
    keep[(st[:, 2] > .4*w) & (st[:, 3] < .008*h)] = 0
    mask = keep[labs]
    # Rules may touch a glyph, so remove the remaining very thin horizontal runs.
    rules = cv2.morphologyEx(mask, cv2.MORPH_OPEN,
                            cv2.getStructuringElement(cv2.MORPH_RECT, (max(31, int(w*.4)), 1)))
    rule_rows += runs(rules.sum(1) > .35*w)
    mask[rules > 0] = 0
    n, labs, st, centroids = cv2.connectedComponentsWithStats(mask, 8)
    useful = st[1:]
    hs = useful[(useful[:, 3] >= .004*h) & (useful[:, 3] < .05*h), 3]
    char_h = float(np.median(hs)) if len(hs) else h*.015
    return mask, labs, st, char_h, rule_rows


def geom_regions(mask, char_h, rule_rows=()):
    """Group line bands using blank gaps, indentation and width changes."""
    h, w = mask.shape
    ys, xs = np.where(mask)
    if len(xs) == 0:
        return []
    left, right = float(np.percentile(xs, 1)), float(np.percentile(xs, 99))
    body_w = max(1, right-left)
    # A few stray pixels must not bridge otherwise separate lines. Identify
    # strong line bands, then restore whole connected components to the nearest
    # band so the threshold does not cut off accents/descenders.
    active = gaussian_filter1d(mask.sum(1).astype(float),.8) >= max(5,w*.02)
    bands = runs(active)
    bands=[(a,b) for a,b in bands if b-a>=max(3,char_h*.25)]
    if not bands:
        return []
    centers=np.array([(a+b)/2 for a,b in bands])
    n,labs,st,centroids=cv2.connectedComponentsWithStats(mask,8)
    assigned=[[] for b in bands]
    for stat,center in zip(st[1:],centroids[1:]):
        x,y,bw,bh,area=stat
        bi=int(np.argmin(abs(centers-center[1])))
        if area>=5 and abs(centers[bi]-center[1])<=max(char_h*1.7,bh):
            assigned[bi].append([int(x),int(y),int(x+bw),int(y+bh)])
    lines = []
    for members in assigned:
        if not members:
            continue
        a=np.array(members)
        x1,y1,x2,y2=int(a[:,0].min()),int(a[:,1].min()),int(a[:,2].max()),int(a[:,3].max())
        centered = (x1-left > .045*body_w and right-x2 > .035*body_w
                    and x2-x1 < .89*body_w)
        lines.append(dict(box=[x1,y1,x2,y2], centered=centered))
    if not lines:
        return []
    gaps = [b['box'][1]-a['box'][3] for a,b in zip(lines,lines[1:])]
    typical_gap = float(np.percentile(gaps, 40)) if gaps else char_h*.3
    gap_limit = max(.65*char_h, 1.7*typical_gap)
    groups = []
    current = [lines[0]]
    for line in lines[1:]:
        a, b = current[-1]['box'], line['box']
        gap = b[1]-a[3]
        ruled = any(a[3]-2 <= (r1+r2)/2 <= b[1]+2 for r1,r2 in rule_rows)
        indent_new = (b[0]-left > .045*body_w and right-a[2] > .08*body_w
                      and not current[-1]['centered'] and not line['centered'])
        changed = current[-1]['centered'] != line['centered']
        # Avoid subdividing verse merely for a slightly wider last line.
        if gap > gap_limit or ruled or indent_new or changed:
            groups.append(current)
            current = []
        current.append(line)
    groups.append(current)
    result=[]
    for group in groups:
        a=np.array([l['box'] for l in group])
        box=[int(a[:,0].min()),int(a[:,1].min()),int(a[:,2].max()),int(a[:,3].max())]
        label='verse_like' if sum(l['centered'] for l in group) > len(group)/2 else 'text_block'
        if box[3] < .12*h:
            label='header'
        elif any((r1+r2)/2 < box[1] and (r1+r2)/2 > .7*h for r1,r2 in rule_rows):
            label='footnote'
        result.append(dict(box=box,label=label,score=None))
    return result


def nms_class_agnostic(items, threshold=.55):
    keep=[]
    for item in sorted(items,key=lambda a:a['score'],reverse=True):
        a=np.array(item['box'],float)
        skip=False
        for other in keep:
            b=np.array(other['box'],float)
            inter=np.maximum(0,np.minimum(a[2:],b[2:])-np.maximum(a[:2],b[:2])).prod()
            area_a=np.maximum(0,a[2:]-a[:2]).prod()
            area_b=np.maximum(0,b[2:]-b[:2]).prod()
            if inter/max(1,area_a+area_b-inter) > threshold:
                skip=True;break
        if not skip:
            keep.append(item)
    return keep


def small_detect(sess,rgb,threshold=.3):
    h,w=rgb.shape[:2]
    x=cv2.resize(rgb,(480,480),interpolation=cv2.INTER_CUBIC).astype(np.float32)/255
    x=(x-np.array([.485,.456,.406],np.float32))/np.array([.229,.224,.225],np.float32)
    dets,n=sess.run(None,{'image':np.transpose(x,(2,0,1))[None].copy(),
                          'scale_factor':np.array([[480/h,480/w]],np.float32)})
    items=[]
    for cls,score,x1,y1,x2,y2 in dets.reshape(-1,6)[:int(n.reshape(-1)[0])]:
        if score < threshold:
            continue
        items.append(dict(box=[float(x1),float(y1),float(x2),float(y2)],
                          label=SMALL_LABELS[int(cls)],score=float(score)))
    items=nms_class_agnostic(items)
    return sorted(items,key=lambda a:(a['box'][1],a['box'][0]))


def v3_detect(sess,rgb,labels,threshold=.3):
    h,w=rgb.shape[:2]
    x=cv2.resize(rgb,(800,800),interpolation=cv2.INTER_CUBIC).astype(np.float32)/255
    # Masks are not requested: this experiment compares axis-aligned rectangles.
    logits,boxes,order_logits=sess.run(['logits','pred_boxes','order_logits'],
                                     {'pixel_values':np.transpose(x,(2,0,1))[None].copy()})
    scores=expit(logits[0]); top=np.argsort(scores.ravel())[-300:][::-1]
    q,cls=top//scores.shape[1],top%scores.shape[1]
    os=expit(order_logits[0])
    # NumPy translation of the official Hugging Face pairwise order-vote rule.
    votes=np.triu(os,1).sum(0)+np.tril(1-os.T,-1).sum(0)
    order=np.empty(300,int);order[np.argsort(votes,kind='stable')]=np.arange(300)
    items=[]
    for qi,ci in zip(q,cls):
        score=float(scores[qi,ci])
        if score < .2:
            continue
        cx,cy,bw,bh=boxes[0,qi]
        box=[float((cx-bw/2)*w),float((cy-bh/2)*h),
             float((cx+bw/2)*w),float((cy+bh/2)*h)]
        items.append(dict(box=box,label=labels[str(ci)],score=score,
                          model_order=int(order[qi]),query_id=int(qi)))
    items.sort(key=lambda a:a['model_order'])
    return [a for a in items if a['score'] >= threshold],items


def rasterize_boxes(items,shape):
    h,w=shape
    out=np.zeros(shape,np.uint8)
    for a in items:
        x1,y1,x2,y2=a['box']
        x1=max(0,int(np.floor(x1)));y1=max(0,int(np.floor(y1)))
        x2=min(w,int(np.ceil(x2)));y2=min(h,int(np.ceil(y2)))
        if x2>x1 and y2>y1:
            out[y1:y2,x1:x2]=1
    return out


def hybrid_regions(items,mask,labs,st,char_h,rules):
    h,w=mask.shape
    cleaned=[]
    for item in items:
        x1,y1,x2,y2=item['box']
        if y1 > .94*h:
            continue
        # Pull intersecting connected components wholly inside the crop,
        # provided the required extension is small. This preserves diacritics.
        ia=np.array([max(0,int(x1)),max(0,int(y1)),min(w,int(np.ceil(x2))),min(h,int(np.ceil(y2)))])
        if ia[2]<=ia[0] or ia[3]<=ia[1]:
            continue
        ids,counts=np.unique(labs[ia[1]:ia[3],ia[0]:ia[2]],return_counts=True)
        for ci,ct in zip(ids,counts):
            if ci==0 or ct < max(2,st[ci,4]*.2):
                continue
            sx,sy,sw,sh,area=st[ci]
            if sx < x1-.025*w or sy < y1-.018*h or sx+sw > x2+.025*w or sy+sh > y2+.018*h:
                continue
            x1=min(x1,sx);y1=min(y1,sy);x2=max(x2,sx+sw);y2=max(y2,sy+sh)
        a=dict(item);a['box']=[max(0,x1-2),max(0,y1-2),min(w,x2+2),min(h,y2+2)]
        a['origin']='model_refined';cleaned.append(a)
    covered=rasterize_boxes(cleaned,mask.shape)
    # Include whole components if any substantial part was missed.
    residual=np.zeros_like(mask)
    for ci in range(1,len(st)):
        x,y,bw,bh,area=st[ci]
        cm=(labs[y:y+bh,x:x+bw]==ci)
        if area>=5 and (cm & (covered[y:y+bh,x:x+bw]==0)).sum() > max(3,area*.15):
            residual[y:y+bh,x:x+bw][cm]=1
    added=geom_regions(residual,char_h,rules)
    for a in added:
        if (a['box'][2]-a['box'][0]) < .025*w and (a['box'][3]-a['box'][1]) < char_h:
            continue
        a['origin']='unassigned_ink';a['label']='recovered'
        cleaned.append(a)
    return sorted(cleaned,key=lambda a:(a['box'][1],a['box'][0]))


def metrics(items,mask,labs,st):
    cover=rasterize_boxes(items,mask.shape)
    ink=int(mask.sum());miss=int((mask & (cover==0)).sum())
    h,w=mask.shape
    partial=0
    for ci in range(1,len(st)):
        x,y,bw,bh,area=st[ci]
        if area<8:
            continue
        cm=labs[y:y+bh,x:x+bw]==ci
        inside=int((cm & (cover[y:y+bh,x:x+bw]>0)).sum())
        if inside >= 3 and area-inside >= max(3,area*.05):
            partial+=1
    return dict(regions=len(items),ink_pixels=ink,uncovered_ink_pixels=miss,
                ink_coverage=1-miss/max(1,ink),partially_covered_components=partial)


def draw_overlay(rgb,items,mask=None,show_missed=False):
    im=Image.fromarray(rgb).convert('RGB')
    if show_missed and mask is not None:
        a=np.asarray(im).copy();miss=(mask>0)&(rasterize_boxes(items,mask.shape)==0)
        miss=cv2.dilate(miss.astype(np.uint8),np.ones((3,3),np.uint8))>0
        a[miss]=[235,40,65];im=Image.fromarray(a)
    d=ImageDraw.Draw(im)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',max(14,im.width//48))
    for i,item in enumerate(items):
        x1,y1,x2,y2=item['box']
        color='#c56c06' if item.get('origin')=='unassigned_ink' else '#087db2'
        if item['label'] in ['header','number','footer','footer_image']:
            color='#7a55ad'
        d.rectangle([x1,y1,x2,y2],outline=color,width=max(2,im.width//450))
        label=str(i+1)
        tb=d.textbbox((0,0),label,font=font);tw=tb[2];th=tb[3]-tb[1]
        tx=max(0,x1-2);ty=max(0,y1-th-6)
        d.rectangle([tx,ty,tx+tw+7,ty+th+6],fill=color)
        d.text((tx+3,ty-tb[1]+2),label,font=font,fill='white')
    return im


def main():
    ap=argparse.ArgumentParser();ap.add_argument('pdf');ap.add_argument('--pages',nargs='*',type=int)
    args=ap.parse_args()
    out=ROOT/'results';out.mkdir(exist_ok=True);(out/'images').mkdir(exist_ok=True)
    document=fitz.open(args.pdf)
    ss=session(ROOT/'models/pp_doclayout_s.onnx');sv=session(ROOT/'models/v3/PP-DocLayoutV3.onnx')
    labels=json.loads((ROOT/'models/v3/config.json').read_text())['id2label']
    records=[]
    for pn in args.pages or PAGES:
        page=document[pn-1];pix=page.get_pixmap(matrix=fitz.Matrix(300/72,300/72),alpha=False)
        rgb=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,3).copy()
        mask,labs,st,char_h,rules=make_mask(rgb)
        times={};t=time.perf_counter();geo=geom_regions(mask,char_h,rules);times['geometry']=time.perf_counter()-t
        t=time.perf_counter();small=small_detect(ss,rgb);times['small']=time.perf_counter()-t
        t=time.perf_counter();large,candidates=v3_detect(sv,rgb,labels);times['large']=time.perf_counter()-t
        strict=[a for a in candidates if a['score']>=.5]
        t=time.perf_counter();hybrid=hybrid_regions(large,mask,labs,st,char_h,rules);times['hybrid_cleanup']=time.perf_counter()-t
        methods={'geometry':geo,'small':small,'large':large,'hybrid':hybrid}
        record=dict(pdf_page=pn,width=pix.width,height=pix.height,pdf_width=float(page.rect.width),
                    pdf_height=float(page.rect.height),character_height=char_h,
                    regions=methods,large_candidates=candidates,timings_seconds=times,
                    metrics={name:metrics(items,mask,labs,st) for name,items in methods.items()},
                    large_default05_regions=strict,
                    large_default05_metrics=metrics(strict,mask,labs,st))
        records.append(record)
        Image.fromarray(rgb).save(out/'images'/f'p{pn:03d}-original.jpg',quality=90)
        for name,items in methods.items():
            draw_overlay(rgb,items,mask,True).save(out/'images'/f'p{pn:03d}-{name}.jpg',quality=88)
        print(json.dumps({'page':pn,'regions':{k:len(v) for k,v in methods.items()},
                          'coverage':{k:round(v['ink_coverage'],4) for k,v in record['metrics'].items()},
                          'times':{k:round(v,3) for k,v in times.items()}}),flush=True)
        (out/'regions.json').write_text(json.dumps(dict(source=Path(args.pdf).name,
             source_sha256=hashlib.sha256(Path(args.pdf).read_bytes()).hexdigest(),source_pages=len(document),
             render_dpi=300,small_threshold=.3,large_threshold=.3,records=records),
             ensure_ascii=False,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)))


if __name__=='__main__':
    main()
