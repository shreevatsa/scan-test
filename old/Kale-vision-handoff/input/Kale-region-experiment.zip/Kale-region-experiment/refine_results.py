#!/usr/bin/env python3
"""Re-score saved model candidates without repeating inference."""
import argparse
import json
from pathlib import Path
import fitz
import numpy as np
from PIL import Image
from compare_regions import ROOT, make_mask, hybrid_regions, metrics, draw_overlay

p=ROOT/'results/regions.json'
data=json.loads(p.read_text())
parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,default=ROOT.parent/'upload'/data['source'])
args=parser.parse_args()
doc=fitz.open(args.source)
for record in data['records']:
    pn=record['pdf_page']
    pix=doc[pn-1].get_pixmap(matrix=fitz.Matrix(300/72,300/72),alpha=False)
    rgb=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,3).copy()
    mask,labs,stats,ch,rules=make_mask(rgb)
    if data['large_threshold']==.5:
        record['large_default05_regions']=record['regions']['large']
        record['large_default05_metrics']=record['metrics']['large']
    large=[a for a in record['large_candidates'] if a['score']>=.3]
    hybrid=hybrid_regions(large,mask,labs,stats,ch,rules)
    for name,items in [('large',large),('hybrid',hybrid)]:
        record['regions'][name]=items
        record['metrics'][name]=metrics(items,mask,labs,stats)
        draw_overlay(rgb,items,mask,True).save(ROOT/'results/images'/f'p{pn:03d}-{name}.jpg',quality=88)
    record.pop('large_low_threshold_metrics',None)
    print(pn,round(record['metrics']['large']['ink_coverage'],4),round(record['metrics']['hybrid']['ink_coverage'],4),flush=True)
data['large_threshold']=.3
p.write_text(json.dumps(data,ensure_ascii=False,indent=2,
                       default=lambda x:x.item() if isinstance(x,np.generic) else str(x)))
