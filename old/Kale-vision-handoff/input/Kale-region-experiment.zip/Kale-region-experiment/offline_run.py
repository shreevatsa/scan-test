#!/usr/bin/env python3
"""Run local analysis with telemetry disabled and network syscalls denied.

Linux only. Model downloads are deliberately a separate, document-free step.
The filter is installed before importing any inference libraries.
"""
import ctypes
import ctypes.util
import errno
import os
import runpy
import socket
import sys

os.environ['ORT_DISABLE_TELEMETRY']='1'
lib=ctypes.CDLL(ctypes.util.find_library('seccomp'),use_errno=True)
lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
lib.seccomp_rule_add.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint]
lib.seccomp_load.argtypes=[ctypes.c_void_p]
lib.seccomp_release.argtypes=[ctypes.c_void_p]
ctx=lib.seccomp_init(0x7fff0000)
if not ctx:
    raise RuntimeError('Could not initialize network restriction')
try:
    for name in [b'socket',b'connect',b'sendto',b'sendmsg',b'sendmmsg']:
        number=lib.seccomp_syscall_resolve_name(name)
        if number>=0 and lib.seccomp_rule_add(ctx,0x00050000|errno.EPERM,number,0)!=0:
            raise RuntimeError('Could not restrict '+name.decode())
    if lib.seccomp_load(ctx)!=0:
        raise RuntimeError('Could not load network restriction')
finally:
    lib.seccomp_release(ctx)
try:
    socket.socket(socket.AF_INET,socket.SOCK_STREAM)
except PermissionError:
    print('Verified: network sockets denied; inference telemetry disabled.',flush=True)
else:
    raise RuntimeError('Network restriction verification failed')
if len(sys.argv)<2:
    raise SystemExit(0)
target=sys.argv[1]
sys.argv=sys.argv[1:]
runpy.run_path(target,run_name='__main__')
